## Electron
If you run the electron the backend runs alone through main.js

## Demo App
![Calendar4Web- Animated gif demo](demo/demo.gif)

