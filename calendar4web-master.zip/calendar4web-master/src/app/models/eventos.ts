export class Eventos {

  constructor(
    public id?: number,
    public titulo?: string,
    public cor_primaria?: string,
    public cor_secundaria?: string,
    public data_inicio?: string,
    public data_fim?: string,
  ){}
}
